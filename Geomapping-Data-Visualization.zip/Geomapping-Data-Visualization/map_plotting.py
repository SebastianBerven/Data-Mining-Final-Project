from mpl_toolkits.basemap import Basemap
import matplotlib.pyplot as plt
import utils



def main():
    data, header = utils.read_table('combined_data.csv', True)
    crime_rate, latitudes, longitudes = [], [], []

    for row in data:
        crime_rate.append(row[header.index("Crime_Rate_per_100000")])
        latitudes.append(row[header.index("Latitude")])
        longitudes.append(row[header.index("Longitude")])

    crime_rate = discretize_data(crime_rate, 3) 

    draw_us_map()
    plt.scatter(latitudes, longitudes, c=crime_rate, zorder=5)
    plt.title("Crime Rate by County")

    plt.show()    
    

def discretize_data(data, num_segs):
    groups = equal_width_bins(data, num_segs)
    rename_data(groups, data)
    return data

def equal_width_bins(data, num_segs):
    width = (max(data)-min(data))/num_segs #Finds width of bins.
    groups = []
    for x in range(num_segs):
        buffer = []
        for num in data:
            if num >= min(data)+(width*x) and num < min(data)+(width*(x+1)): #Apportions data to correct bin.
                buffer.append(num)
        groups.append(buffer)
    groups[num_segs-1].append(max(data))
    return groups

def rename_data(groups, data):
    for x in range(len(data)):
        if data[x] == 0:
            data[x] = 'w'
        elif data[x] in groups[0]:
            data[x] = "g"
        elif data[x] in groups[1]:
            data[x] = "y"
        elif data[x] in groups[2]:
            data[x] = "r"
    


def draw_us_map():
    # Set the lower left and upper right limits of the bounding box:
    lllon = -119
    urlon = -64
    lllat = 22.0
    urlat = 50.5
    # and calculate a centerpoint, needed for the projection:
    centerlon = float(lllon + urlon) / 2.0
    centerlat = float(lllat + urlat) / 2.0

    # resolutions can be: 'c'rude, 'l'ow, 'i'ntermediate, 'h'igh, 'f'ull
    m = Basemap(resolution='c', llcrnrlon = lllon, urcrnrlon = urlon, lon_0 = centerlon, llcrnrlat = lllat, urcrnrlat = urlat, lat_0 = centerlat, projection='tmerc')

    # Read county boundaries
    shp_info = m.readshapefile('tl_2016_us_county','counties',drawbounds=True)



if __name__ == "__main__":
    main()